package com.cg.billing.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;
import com.cg.billing.services.BillingServices;

@Controller
public class BillingServicesController {
@Autowired
private BillingServices billingServices;

@RequestMapping("/registerCustomer")
public ModelAndView registerCustomer(@Valid@ModelAttribute Customer customer,BindingResult result) {
	if(result.hasErrors())return new ModelAndView("registrationPage");
	customer=billingServices.acceptCustomerDetails(customer);
	return new ModelAndView("registrationPage", "customer", customer);
}
@RequestMapping("/customerDetails")
public ModelAndView getCustomerDetails(@RequestParam int customerId)throws CustomerDetailsNotFoundException {
	Customer customer=billingServices.getCustomerDetails(customerId);
	return new ModelAndView("findCustomerDetailsPage", "customer", customer);
}
@RequestMapping("/allCustomerDetails")
public ModelAndView getAllCustomerDetails()throws CustomerDetailsNotFoundException {
	List<Customer> customers=billingServices.getAllCustomerDetails();
	return new ModelAndView("findAllCustomerDetailsPage", "customers", customers);
}
@RequestMapping("/postPaidAccountDetails")
public ModelAndView getPostPaidAccountDetails(@RequestParam int customerID, long mobileNo )throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException {
	PostpaidAccount postpaidAccount=billingServices.getPostPaidAccountDetails(customerID, mobileNo);
	return new ModelAndView("findPostPaidAccountDetailsPage", "postpaidAccount", postpaidAccount);
}
@RequestMapping("/allPostPaidAccountDetails")
public ModelAndView getAllPostPaidAccountDetails(@RequestParam int customerId)throws CustomerDetailsNotFoundException {
	List<PostpaidAccount> accounts=billingServices.getCustomerAllPostpaidAccountsDetails(customerId);
	return new ModelAndView("findAllPostPaidAccountDetailsPage", "accounts", accounts);
}
@RequestMapping("/billDetails")
public ModelAndView getMobileBillDetails(@RequestParam int customerID, long mobileNo, String billMonth)throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException, 
InvalidBillMonthException, BillDetailsNotFoundException {
	Bill bill=billingServices.getMobileBillDetails(customerID, mobileNo, billMonth);
	return new ModelAndView("findBillDetailsPage", "bill", bill);
}
@RequestMapping("/allBillDetails")
public ModelAndView getAllMobileBillDetails(@RequestParam int customerID,long mobileNo)throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException, 
InvalidBillMonthException, BillDetailsNotFoundException {
	List<Bill> bills=billingServices.getCustomerPostPaidAccountAllBillDetails(customerID, mobileNo);
	return new ModelAndView("findAllBillDetailsPage", "bills", bills);
}
@RequestMapping("/planDetails")
public ModelAndView getPlanDetails(@RequestParam int customerID, long mobileNo)throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException,PlanDetailsNotFoundException{
	Plan plan=billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
	return new ModelAndView("findPlanDetailsPage", "plan", plan);
}
@RequestMapping("/allPlanDetails")
public ModelAndView getAllPlanDetails()throws CustomerDetailsNotFoundException,PostpaidAccountNotFoundException,PlanDetailsNotFoundException{
	List<Plan> plans=billingServices.getPlanAllDetails();
	return new ModelAndView("findAllPlanDetailsPage", "plans", plans);
}
}
