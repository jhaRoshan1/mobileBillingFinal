package com.cg.billing.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.billing.beans.Customer;

@Controller
public class URIController {
private Customer customer;

@RequestMapping(value= {"/","index"})
public String getIndexPage() {
	return "indexpage";
}
@RequestMapping("/registration")
public String getRegistrationPage() {
	return "registrationPage";
}
	@RequestMapping("/customerDetails")
	public String getCustomerDetails() {
		return "findCustomerDetailsPage";
	}
	@RequestMapping("/allCustomerDetails")
	public String getAllCustomerDetails() {
		return "findAllCustomerDetailsPage";
	}
	@RequestMapping("/postpaidAccountDetails")
	public String getPostpaidAccountDetails() {
		return "findPostPaidAccountDetailsPage";
	}
	@RequestMapping("/allPostpaidAccountDetails")
	public String getallPostpaidAccountDetails() {
		return "findAllPostPaidAccountDetailsPage";
	}
	@RequestMapping("/billDetails")
	public String getbillDetails() {
		return "findBillDetailsPage";
	}
	@RequestMapping("/allBillDetails")
	public String getallBillDetails() {
		return "findAllBillDetailsPage";
	}
	@RequestMapping("/planDetails")
	public String getplanDetails() {
		return "findPlanDetailsPage";
	}
	@RequestMapping("/allPlanDetails")
	public String getallPlanDetails() {
		return "findAllPlanDetailsPage";
	}
}
