package com.cg.billing.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.billing.beans.Bill;
import com.cg.billing.beans.Customer;
import com.cg.billing.beans.Plan;
import com.cg.billing.beans.PostpaidAccount;
import com.cg.billing.daoservices.BillDAO;
import com.cg.billing.daoservices.CustomerDAO;
import com.cg.billing.daoservices.PlanDAO;
import com.cg.billing.daoservices.PostPaidAccountDAO;
import com.cg.billing.exceptions.BillDetailsNotFoundException;
import com.cg.billing.exceptions.CustomerDetailsNotFoundException;
import com.cg.billing.exceptions.InvalidBillMonthException;
import com.cg.billing.exceptions.PlanDetailsNotFoundException;
import com.cg.billing.exceptions.PostpaidAccountNotFoundException;

public class BillingServicesImpl implements BillingServices{
	@Autowired
	private BillDAO billDao;
	@Autowired
	private CustomerDAO customerDao;
	@Autowired
	private PlanDAO planDao;
	@Autowired
	private PostPaidAccountDAO postPaidAccountDAO;

	@Override
	public List<Plan> getPlanAllDetails() {
		return planDao.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer){
		return customerDao.save(customer);
	}
	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		Plan plan=planDao.findById(planID).orElseThrow(()->new PlanDetailsNotFoundException());
		PostpaidAccount account=new PostpaidAccount(plan, customer);
		account=postPaidAccountDAO.save(account);
		return account.getMobileNo();
	}
	@Override
	public double generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException {

		return 0;
	}
	@Override
	public Customer getCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
		return customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found"+customerID));
	}
	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}
	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {

		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer details not found"+customerID));
		ArrayList<PostpaidAccount> postpaidAccounts =  new ArrayList<PostpaidAccount>(customer.getPostpaidAccounts().values());
		boolean flag = false;
		PostpaidAccount pAccount = null;
		for(PostpaidAccount postpaidAccount: postpaidAccounts) {
			if(postpaidAccount.getMobileNo() == mobileNo) {
				flag = true;
				pAccount = postpaidAccount;
			}
		}
		if(!flag)
			throw new PostpaidAccountNotFoundException("PostPaid account not found");
		return pAccount;
	}

	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		Map<Long, PostpaidAccount> customerDetail=customer.getPostpaidAccounts();
		return new ArrayList<PostpaidAccount>(customerDetail.values());
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException {
PostpaidAccount customer=getPostPaidAccountDetails(customerID, mobileNo);
Map<Integer, Bill> bills=customer.getBills();
for(Bill bill:bills.values()) {
	if(bill.getBillMonth().equals(billMonth))
		return bill;
}
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
PostpaidAccount account=postPaidAccountDAO.findById((long) customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		return new ArrayList<Bill>(account.getBills().values());
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
		PostpaidAccount postpaidAccount=customer.getPostpaidAccounts().get(mobileNo);
		postpaidAccount.setPlan(planDao.findById(planID).orElseThrow(()->new PostpaidAccountNotFoundException()));
		postPaidAccountDAO.save(postpaidAccount);

		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException {
		PostpaidAccount account=getPostPaidAccountDetails(customerID, mobileNo);
		postPaidAccountDAO.delete(account);
		return true;
	}

	/*@Override
	public boolean removeCustomerDetails(int customerID) throws CustomerDetailsNotFoundException {
Customer customer=customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException());
for(PostpaidAccount postPaid:customerDao.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException()).getPostpaidAccounts(){
	postPaidAccountDAO.delete(postPaid);
		}
customerDao.delete(customer);
		return false;
	}*/

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, PlanDetailsNotFoundException {
		return getPostPaidAccountDetails(customerID, mobileNo).getPlan();
	}

}
